# ECharts Field Drupal Module #

This module create a new field type which allow the user setting the display of a chart reder by the library Baidu ECharts  

## Requirements ##

You only need the module [Baidu ECharts](https://www.drupal.org/project/echarts) and it and be sure that it is enabled
# echarts_field
