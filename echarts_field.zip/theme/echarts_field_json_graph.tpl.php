<div class="<?php print implode(' ', $classes_array); ?>">
  <?php print($graph); ?>
</div>